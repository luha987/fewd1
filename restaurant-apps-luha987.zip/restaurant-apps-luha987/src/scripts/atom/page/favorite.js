
const Favorite = {
  async render() {
    return `
      <div class="container">
        <h2 class="text-heading">Restaurant Favoritku</h2>
        <div id="restaurant">

        </div>
        </div>
      </div>`;
  },

};

export default Favorite;
