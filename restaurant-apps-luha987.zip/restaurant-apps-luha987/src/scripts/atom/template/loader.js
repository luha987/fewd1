const loader = {
  loaderTemplate() {
    return `<div class="loader">
        <span></span>
        <span></span>
        <span></span>
    </div>`;
  },

  OfflineTemplate() {
    return `
        <div class="content">
            <h2>Lagi error Boss Tolong Refrest Situsnya <img src="./images/sad-emoji.png" alt="people reviewer"></h2>
        </div>`;
  },
};

export default loader;
