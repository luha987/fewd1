class HeroKu extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    this.innerHTML = `
            <div class="jumbotron">
                <div class="image-content">
                    <picture>
                        <img src='./images/heros/hero-image.jpg' class="low-res-image lazyload" alt="jumbotron" role="presentation"
                            srcset="./images/heros/hero-image-small.jpg 480w, ./images/heros/hero-image-large.jpg 800w"
                            sizes="(max-width: 600px) 480px, 800px">
                    </picture>
                </div>
                <div class="container">
                    <div class="content-wrapper">
                        <h2>Daftar Restaurant Di Indonesia</h2>
                        <h2>&#8659; &#8659; &#8659;</h2>
                        <div class="scroll">
                        </div>
                    </div>
                </div>
            </div>`;
  }
}

customElements.define('my-hero', HeroKu);
