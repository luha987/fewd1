class MyFooter extends HTMLElement {
  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render();
  }

  render() {
    this.shadow.innerHTML = `
        <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color:red;
        }
        :host {
            width: 100%;
            text-align: center;
            font-size: 1.6rem;
            padding: 20px;
            color:white;
            transition: .5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }


        </style>
        <hr>
        <p> Copyright© 2021 - Luha987</p>
        `;
  }
}

customElements.define('my-footer', MyFooter);
