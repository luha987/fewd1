const DarkMode = {
  init({ toggle, currentTheme }) {
    toggle.addEventListener('change', (event) => {
      this._switchTheme(event);
    });
    if (currentTheme) {
      document.documentElement.setAttribute('data-theme', currentTheme);
      if (currentTheme === 'dark') {
        toggle.checked = true;
      }
    }
  },
};

export default DarkMode;
